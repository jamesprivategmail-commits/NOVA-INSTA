"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-08-01
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

user_role = pg.ENUM("user", "moderator", "admin", name="userrole")
notification_type = pg.ENUM("like", "comment", "follow", "message", "story_view", name="notificationtype")
report_target_type = pg.ENUM("post", "comment", "user", name="reporttargettype")
report_status = pg.ENUM("pending", "resolved", "dismissed", name="reportstatus")
ad_status = pg.ENUM("draft", "active", "paused", "ended", name="adstatus")


def upgrade() -> None:
    bind = op.get_bind()
    user_role.create(bind, checkfirst=True)
    notification_type.create(bind, checkfirst=True)
    report_target_type.create(bind, checkfirst=True)
    report_status.create(bind, checkfirst=True)
    ad_status.create(bind, checkfirst=True)

    op.create_table(
        "users",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("username", sa.String(30), nullable=False, unique=True),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("display_name", sa.String(60)),
        sa.Column("bio", sa.String(160), server_default=""),
        sa.Column("avatar_url", sa.String(500), server_default=""),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
        sa.Column("role", user_role, nullable=False, server_default="user"),
        sa.Column("is_verified", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("is_banned", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("ban_reason", sa.String(500)),
        sa.Column("banned_at", sa.DateTime),
    )
    op.create_index("ix_users_username", "users", ["username"])
    op.create_index("ix_users_email", "users", ["email"])

    op.create_table(
        "posts",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("author_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("media_url", sa.String(500), nullable=False),
        sa.Column("media_type", sa.String(10), server_default="image"),
        sa.Column("caption", sa.String(2200), server_default=""),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )
    op.create_index("ix_posts_author_id", "posts", ["author_id"])
    op.create_index("ix_posts_created_at", "posts", ["created_at"])

    op.create_table(
        "likes",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("user_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("post_id", pg.UUID(as_uuid=False), sa.ForeignKey("posts.id"), nullable=False),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
        sa.UniqueConstraint("user_id", "post_id", name="uq_like_user_post"),
    )
    op.create_index("ix_likes_user_id", "likes", ["user_id"])
    op.create_index("ix_likes_post_id", "likes", ["post_id"])

    op.create_table(
        "comments",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("user_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("post_id", pg.UUID(as_uuid=False), sa.ForeignKey("posts.id"), nullable=False),
        sa.Column("text", sa.String(500), nullable=False),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )
    op.create_index("ix_comments_user_id", "comments", ["user_id"])
    op.create_index("ix_comments_post_id", "comments", ["post_id"])

    op.create_table(
        "follows",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("follower_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("followee_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
        sa.UniqueConstraint("follower_id", "followee_id", name="uq_follow_pair"),
    )
    op.create_index("ix_follows_follower_id", "follows", ["follower_id"])
    op.create_index("ix_follows_followee_id", "follows", ["followee_id"])

    op.create_table(
        "notifications",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("recipient_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("actor_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("type", notification_type, nullable=False),
        sa.Column("post_id", pg.UUID(as_uuid=False), sa.ForeignKey("posts.id"), nullable=True),
        sa.Column("is_read", sa.Boolean, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )
    op.create_index("ix_notifications_recipient_id", "notifications", ["recipient_id"])
    op.create_index("ix_notifications_created_at", "notifications", ["created_at"])

    op.create_table(
        "conversations",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )

    op.create_table(
        "conversation_participants",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("conversation_id", pg.UUID(as_uuid=False), sa.ForeignKey("conversations.id"), nullable=False),
        sa.Column("user_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("last_read_at", sa.DateTime),
        sa.UniqueConstraint("conversation_id", "user_id", name="uq_conversation_user"),
    )
    op.create_index("ix_conversation_participants_conversation_id", "conversation_participants", ["conversation_id"])
    op.create_index("ix_conversation_participants_user_id", "conversation_participants", ["user_id"])

    op.create_table(
        "direct_messages",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("conversation_id", pg.UUID(as_uuid=False), sa.ForeignKey("conversations.id"), nullable=False),
        sa.Column("sender_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("text", sa.String(2000), server_default=""),
        sa.Column("media_url", sa.String(500)),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )
    op.create_index("ix_direct_messages_conversation_id", "direct_messages", ["conversation_id"])
    op.create_index("ix_direct_messages_sender_id", "direct_messages", ["sender_id"])
    op.create_index("ix_direct_messages_created_at", "direct_messages", ["created_at"])

    op.create_table(
        "stories",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("author_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("media_url", sa.String(500), nullable=False),
        sa.Column("media_type", sa.String(10), server_default="image"),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
        sa.Column("expires_at", sa.DateTime, nullable=False),
    )
    op.create_index("ix_stories_author_id", "stories", ["author_id"])
    op.create_index("ix_stories_created_at", "stories", ["created_at"])
    op.create_index("ix_stories_expires_at", "stories", ["expires_at"])

    op.create_table(
        "story_views",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("story_id", pg.UUID(as_uuid=False), sa.ForeignKey("stories.id"), nullable=False),
        sa.Column("viewer_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
        sa.UniqueConstraint("story_id", "viewer_id", name="uq_story_viewer"),
    )
    op.create_index("ix_story_views_story_id", "story_views", ["story_id"])
    op.create_index("ix_story_views_viewer_id", "story_views", ["viewer_id"])

    op.create_table(
        "push_devices",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("user_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("token", sa.String(255), nullable=False),
        sa.Column("platform", sa.String(10), server_default="ios"),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
        sa.UniqueConstraint("user_id", "token", name="uq_push_user_token"),
    )
    op.create_index("ix_push_devices_user_id", "push_devices", ["user_id"])

    op.create_table(
        "reports",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("reporter_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("target_type", report_target_type, nullable=False),
        sa.Column("target_id", pg.UUID(as_uuid=False), nullable=False),
        sa.Column("reason", sa.String(500), nullable=False),
        sa.Column("status", report_status, nullable=False, server_default="pending"),
        sa.Column("resolved_by", pg.UUID(as_uuid=False), sa.ForeignKey("users.id")),
        sa.Column("resolution_note", sa.String(500)),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
        sa.Column("resolved_at", sa.DateTime),
    )
    op.create_index("ix_reports_reporter_id", "reports", ["reporter_id"])
    op.create_index("ix_reports_target_id", "reports", ["target_id"])
    op.create_index("ix_reports_status", "reports", ["status"])
    op.create_index("ix_reports_created_at", "reports", ["created_at"])

    op.create_table(
        "ad_campaigns",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("advertiser_name", sa.String(120), nullable=False),
        sa.Column("media_url", sa.String(500), nullable=False),
        sa.Column("target_url", sa.String(500), nullable=False),
        sa.Column("caption", sa.String(500), server_default=""),
        sa.Column("budget_cents", sa.String(20), server_default="0"),
        sa.Column("status", ad_status, nullable=False, server_default="draft"),
        sa.Column("starts_at", sa.DateTime),
        sa.Column("ends_at", sa.DateTime),
        sa.Column("created_by", pg.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )
    op.create_index("ix_ad_campaigns_status", "ad_campaigns", ["status"])

    op.create_table(
        "ad_events",
        sa.Column("id", pg.UUID(as_uuid=False), primary_key=True),
        sa.Column("ad_id", pg.UUID(as_uuid=False), sa.ForeignKey("ad_campaigns.id"), nullable=False),
        sa.Column("user_id", pg.UUID(as_uuid=False), sa.ForeignKey("users.id")),
        sa.Column("event_type", sa.String(10), nullable=False),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )
    op.create_index("ix_ad_events_ad_id", "ad_events", ["ad_id"])
    op.create_index("ix_ad_events_created_at", "ad_events", ["created_at"])


def downgrade() -> None:
    op.drop_table("ad_events")
    op.drop_table("ad_campaigns")
    op.drop_table("reports")
    op.drop_table("push_devices")
    op.drop_table("story_views")
    op.drop_table("stories")
    op.drop_table("direct_messages")
    op.drop_table("conversation_participants")
    op.drop_table("conversations")
    op.drop_table("notifications")
    op.drop_table("follows")
    op.drop_table("comments")
    op.drop_table("likes")
    op.drop_table("posts")
    op.drop_table("users")

    bind = op.get_bind()
    ad_status.drop(bind, checkfirst=True)
    report_status.drop(bind, checkfirst=True)
    report_target_type.drop(bind, checkfirst=True)
    notification_type.drop(bind, checkfirst=True)
    user_role.drop(bind, checkfirst=True)
