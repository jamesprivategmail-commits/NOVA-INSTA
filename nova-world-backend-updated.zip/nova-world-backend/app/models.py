import uuid
import enum
from datetime import datetime
from sqlalchemy import (
    Column, String, Text, DateTime, ForeignKey, Enum, UniqueConstraint, Boolean
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .database import Base


def gen_uuid():
    return str(uuid.uuid4())


class UserRole(str, enum.Enum):
    user = "user"
    moderator = "moderator"
    admin = "admin"


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    username = Column(String(30), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    display_name = Column(String(60))
    bio = Column(String(160), default="")
    avatar_url = Column(String(500), default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    role = Column(Enum(UserRole), default=UserRole.user, nullable=False, server_default="user")
    is_verified = Column(Boolean, default=False, nullable=False, server_default="false")
    is_banned = Column(Boolean, default=False, nullable=False, server_default="false")
    ban_reason = Column(String(500))
    banned_at = Column(DateTime)

    posts = relationship("Post", back_populates="author", cascade="all, delete-orphan")


class Post(Base):
    __tablename__ = "posts"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    author_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    media_url = Column(String(500), nullable=False)
    media_type = Column(String(10), default="image")  # image | video
    caption = Column(String(2200), default="")
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    author = relationship("User", back_populates="posts")
    likes = relationship("Like", back_populates="post", cascade="all, delete-orphan")
    comments = relationship("Comment", back_populates="post", cascade="all, delete-orphan")


class Like(Base):
    __tablename__ = "likes"
    __table_args__ = (UniqueConstraint("user_id", "post_id", name="uq_like_user_post"),)

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    post_id = Column(UUID(as_uuid=False), ForeignKey("posts.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    post = relationship("Post", back_populates="likes")


class Comment(Base):
    __tablename__ = "comments"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    post_id = Column(UUID(as_uuid=False), ForeignKey("posts.id"), nullable=False, index=True)
    text = Column(String(500), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    post = relationship("Post", back_populates="comments")


class Follow(Base):
    __tablename__ = "follows"
    __table_args__ = (UniqueConstraint("follower_id", "followee_id", name="uq_follow_pair"),)

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    follower_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    followee_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class NotificationType(str, enum.Enum):
    like = "like"
    comment = "comment"
    follow = "follow"
    message = "message"
    story_view = "story_view"


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    recipient_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    actor_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    type = Column(Enum(NotificationType), nullable=False)
    post_id = Column(UUID(as_uuid=False), ForeignKey("posts.id"), nullable=True)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)


# ---------------------------------------------------------------------------
# Direct messages
# ---------------------------------------------------------------------------

class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    created_at = Column(DateTime, default=datetime.utcnow)

    participants = relationship("ConversationParticipant", back_populates="conversation", cascade="all, delete-orphan")
    messages = relationship("DirectMessage", back_populates="conversation", cascade="all, delete-orphan")


class ConversationParticipant(Base):
    __tablename__ = "conversation_participants"
    __table_args__ = (UniqueConstraint("conversation_id", "user_id", name="uq_conversation_user"),)

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    conversation_id = Column(UUID(as_uuid=False), ForeignKey("conversations.id"), nullable=False, index=True)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    last_read_at = Column(DateTime)

    conversation = relationship("Conversation", back_populates="participants")


class DirectMessage(Base):
    __tablename__ = "direct_messages"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    conversation_id = Column(UUID(as_uuid=False), ForeignKey("conversations.id"), nullable=False, index=True)
    sender_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    text = Column(String(2000), default="")
    media_url = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    conversation = relationship("Conversation", back_populates="messages")


# ---------------------------------------------------------------------------
# Stories (24h ephemeral posts)
# ---------------------------------------------------------------------------

class Story(Base):
    __tablename__ = "stories"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    author_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    media_url = Column(String(500), nullable=False)
    media_type = Column(String(10), default="image")
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    expires_at = Column(DateTime, nullable=False, index=True)


class StoryView(Base):
    __tablename__ = "story_views"
    __table_args__ = (UniqueConstraint("story_id", "viewer_id", name="uq_story_viewer"),)

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    story_id = Column(UUID(as_uuid=False), ForeignKey("stories.id"), nullable=False, index=True)
    viewer_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# Push notification device tokens
# ---------------------------------------------------------------------------

class PushDevice(Base):
    __tablename__ = "push_devices"
    __table_args__ = (UniqueConstraint("user_id", "token", name="uq_push_user_token"),)

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    token = Column(String(255), nullable=False)
    platform = Column(String(10), default="ios")  # ios | android | web
    created_at = Column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# Moderation: user/content reports reviewed by admins & moderators
# ---------------------------------------------------------------------------

class ReportTargetType(str, enum.Enum):
    post = "post"
    comment = "comment"
    user = "user"


class ReportStatus(str, enum.Enum):
    pending = "pending"
    resolved = "resolved"
    dismissed = "dismissed"


class Report(Base):
    __tablename__ = "reports"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    reporter_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    target_type = Column(Enum(ReportTargetType), nullable=False)
    target_id = Column(UUID(as_uuid=False), nullable=False, index=True)
    reason = Column(String(500), nullable=False)
    status = Column(Enum(ReportStatus), default=ReportStatus.pending, nullable=False, server_default="pending", index=True)
    resolved_by = Column(UUID(as_uuid=False), ForeignKey("users.id"))
    resolution_note = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    resolved_at = Column(DateTime)


# ---------------------------------------------------------------------------
# Ad campaigns (transparent, disclosed promotion only — see admin router docs)
# ---------------------------------------------------------------------------

class AdStatus(str, enum.Enum):
    draft = "draft"
    active = "active"
    paused = "paused"
    ended = "ended"


class AdCampaign(Base):
    __tablename__ = "ad_campaigns"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    name = Column(String(120), nullable=False)
    advertiser_name = Column(String(120), nullable=False)
    media_url = Column(String(500), nullable=False)
    target_url = Column(String(500), nullable=False)
    caption = Column(String(500), default="")
    budget_cents = Column(String(20), default="0")
    status = Column(Enum(AdStatus), default=AdStatus.draft, nullable=False, server_default="draft", index=True)
    starts_at = Column(DateTime)
    ends_at = Column(DateTime)
    created_by = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class AdEvent(Base):
    """Impression/click tracking, always labeled as an ad — used for real advertiser
    reporting, never for disguising an ad as organic engagement."""
    __tablename__ = "ad_events"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    ad_id = Column(UUID(as_uuid=False), ForeignKey("ad_campaigns.id"), nullable=False, index=True)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"))
    event_type = Column(String(10), nullable=False)  # impression | click
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
