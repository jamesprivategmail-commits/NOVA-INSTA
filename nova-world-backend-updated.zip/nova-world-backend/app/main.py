from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import auth, users, posts, notifications, admin, reports, messages, stories, ads

# Table creation is now handled by Alembic migrations (see /alembic and README:
# "Database migrations"). Run `alembic upgrade head` on deploy instead of relying
# on create_all, which can't handle schema changes to existing tables.

app = FastAPI(title="Nova World API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten to your actual web/mobile origins before launch
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(posts.router)
app.include_router(notifications.router)
app.include_router(admin.router)
app.include_router(reports.router)
app.include_router(messages.router)
app.include_router(stories.router)
app.include_router(ads.router)


@app.get("/health")
def health():
    return {"status": "ok"}
