from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field, ConfigDict


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=30, pattern=r"^[a-zA-Z0-9._]+$")
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    display_name: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    username: str
    display_name: Optional[str] = None
    bio: str
    avatar_url: str
    created_at: datetime
    role: str = "user"
    is_verified: bool = False
    is_banned: bool = False


class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class UserUpdate(BaseModel):
    display_name: Optional[str] = None
    bio: Optional[str] = Field(default=None, max_length=160)


class CommentCreate(BaseModel):
    text: str = Field(min_length=1, max_length=500)


class CommentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    user_id: str
    text: str
    created_at: datetime


class PostCreate(BaseModel):
    caption: str = Field(default="", max_length=2200)


class PostOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    author_id: str
    media_url: str
    media_type: str
    caption: str
    created_at: datetime
    like_count: int = 0
    comment_count: int = 0
    liked_by_me: bool = False


class NotificationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    actor_id: str
    type: str
    post_id: Optional[str]
    is_read: bool
    created_at: datetime


# ---------------------------------------------------------------------------
# Admin: users & moderation
# ---------------------------------------------------------------------------

class AdminUserOut(UserOut):
    email: str
    ban_reason: Optional[str] = None


class BanRequest(BaseModel):
    reason: str = Field(min_length=1, max_length=500)


class RoleUpdate(BaseModel):
    role: str = Field(pattern=r"^(user|moderator|admin)$")


class ReportCreate(BaseModel):
    target_type: str = Field(pattern=r"^(post|comment|user)$")
    target_id: str
    reason: str = Field(min_length=1, max_length=500)


class ReportOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    reporter_id: str
    target_type: str
    target_id: str
    reason: str
    status: str
    resolution_note: Optional[str] = None
    created_at: datetime
    resolved_at: Optional[datetime] = None


class ReportResolve(BaseModel):
    status: str = Field(pattern=r"^(resolved|dismissed)$")
    resolution_note: Optional[str] = Field(default=None, max_length=500)


class AdminStats(BaseModel):
    total_users: int
    verified_users: int
    banned_users: int
    total_posts: int
    total_reports_pending: int
    active_ads: int
    signups_last_7_days: int


# ---------------------------------------------------------------------------
# Direct messages
# ---------------------------------------------------------------------------

class MessageCreate(BaseModel):
    text: str = Field(default="", max_length=2000)
    media_url: Optional[str] = Field(default=None, max_length=500)


class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    conversation_id: str
    sender_id: str
    text: str
    media_url: Optional[str] = None
    created_at: datetime


class ConversationOut(BaseModel):
    id: str
    other_user: UserOut
    last_message: Optional[MessageOut] = None
    unread_count: int = 0
    created_at: datetime


# ---------------------------------------------------------------------------
# Stories
# ---------------------------------------------------------------------------

class StoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    author_id: str
    media_url: str
    media_type: str
    created_at: datetime
    expires_at: datetime
    view_count: int = 0
    viewed_by_me: bool = False


class StoryFeedGroup(BaseModel):
    author: UserOut
    stories: List[StoryOut]
    has_unseen: bool


# ---------------------------------------------------------------------------
# Push devices
# ---------------------------------------------------------------------------

class PushDeviceRegister(BaseModel):
    token: str = Field(min_length=1, max_length=255)
    platform: str = Field(default="ios", pattern=r"^(ios|android|web)$")


# ---------------------------------------------------------------------------
# Ads (transparent/disclosed promotion — see routers/admin.py docstring)
# ---------------------------------------------------------------------------

class AdCampaignCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    advertiser_name: str = Field(min_length=1, max_length=120)
    media_url: str = Field(min_length=1, max_length=500)
    target_url: str = Field(min_length=1, max_length=500)
    caption: str = Field(default="", max_length=500)
    budget_cents: int = Field(ge=0)
    starts_at: Optional[datetime] = None
    ends_at: Optional[datetime] = None


class AdCampaignUpdate(BaseModel):
    status: Optional[str] = Field(default=None, pattern=r"^(draft|active|paused|ended)$")
    budget_cents: Optional[int] = Field(default=None, ge=0)
    ends_at: Optional[datetime] = None


class AdCampaignOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    advertiser_name: str
    media_url: str
    target_url: str
    caption: str
    budget_cents: int
    status: str
    starts_at: Optional[datetime] = None
    ends_at: Optional[datetime] = None
    created_at: datetime
    impressions: int = 0
    clicks: int = 0
