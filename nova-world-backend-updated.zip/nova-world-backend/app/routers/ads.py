from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import and_, or_
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import AdCampaign, AdStatus, AdEvent, User
from ..schemas import AdCampaignOut
from ..auth import get_optional_user

router = APIRouter(prefix="/ads", tags=["ads"])


@router.get("/active", response_model=List[AdCampaignOut])
def active_ads(limit: int = Query(5, le=10), db: Session = Depends(get_db)):
    """Ads to splice into the feed client-side, always rendered with a visible
    'Sponsored' label — this endpoint is the only sanctioned way to promote
    content, as opposed to inflating a post's real engagement numbers."""
    now = datetime.utcnow()
    ads = (
        db.query(AdCampaign)
        .filter(
            AdCampaign.status == AdStatus.active,
            or_(AdCampaign.starts_at.is_(None), AdCampaign.starts_at <= now),
            or_(AdCampaign.ends_at.is_(None), AdCampaign.ends_at >= now),
        )
        .order_by(AdCampaign.created_at.desc())
        .limit(limit)
        .all()
    )
    return [
        AdCampaignOut(
            id=a.id, name=a.name, advertiser_name=a.advertiser_name, media_url=a.media_url,
            target_url=a.target_url, caption=a.caption, budget_cents=int(a.budget_cents),
            status=a.status.value, starts_at=a.starts_at, ends_at=a.ends_at, created_at=a.created_at,
        )
        for a in ads
    ]


@router.post("/{ad_id}/impression", status_code=204)
def record_impression(ad_id: str, db: Session = Depends(get_db), viewer: Optional[User] = Depends(get_optional_user)):
    if not db.query(AdCampaign).filter(AdCampaign.id == ad_id).first():
        raise HTTPException(status_code=404, detail="Ad not found")
    db.add(AdEvent(ad_id=ad_id, user_id=viewer.id if viewer else None, event_type="impression"))
    db.commit()


@router.post("/{ad_id}/click", status_code=204)
def record_click(ad_id: str, db: Session = Depends(get_db), viewer: Optional[User] = Depends(get_optional_user)):
    if not db.query(AdCampaign).filter(AdCampaign.id == ad_id).first():
        raise HTTPException(status_code=404, detail="Ad not found")
    db.add(AdEvent(ad_id=ad_id, user_id=viewer.id if viewer else None, event_type="click"))
    db.commit()
