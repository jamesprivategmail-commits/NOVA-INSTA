"""
Admin API.

Scope, deliberately: this router lets admins/moderators verify accounts,
ban/unban users, review reported content, delete posts/comments that break
policy, and run *disclosed* ad campaigns with real impression/click tracking.

It intentionally does NOT let anyone inflate follower/like/view counts or
force a specific post to "go viral." That would misrepresent organic
engagement to your own users and to advertisers — the honest way to promote
a post is the AdCampaign flow below, which always renders as a labeled ad.
If you want a "Staff Picks" style boost instead, add a `featured` flag to
Post and surface it in a clearly-labeled feed section — happy to build that
if useful.
"""
from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import (
    User, UserRole, Post, Comment, Report, ReportStatus, ReportTargetType,
    AdCampaign, AdStatus, AdEvent,
)
from ..schemas import (
    AdminUserOut, BanRequest, RoleUpdate, ReportOut, ReportResolve, AdminStats,
    AdCampaignCreate, AdCampaignUpdate, AdCampaignOut,
)
from ..auth import get_current_admin, get_current_moderator

router = APIRouter(prefix="/admin", tags=["admin"])


# ---------------------------------------------------------------------------
# Dashboard stats
# ---------------------------------------------------------------------------

@router.get("/stats", response_model=AdminStats)
def get_stats(db: Session = Depends(get_db), _: User = Depends(get_current_moderator)):
    week_ago = datetime.utcnow() - timedelta(days=7)
    return AdminStats(
        total_users=db.query(func.count(User.id)).scalar(),
        verified_users=db.query(func.count(User.id)).filter(User.is_verified.is_(True)).scalar(),
        banned_users=db.query(func.count(User.id)).filter(User.is_banned.is_(True)).scalar(),
        total_posts=db.query(func.count(Post.id)).scalar(),
        total_reports_pending=db.query(func.count(Report.id)).filter(Report.status == ReportStatus.pending).scalar(),
        active_ads=db.query(func.count(AdCampaign.id)).filter(AdCampaign.status == AdStatus.active).scalar(),
        signups_last_7_days=db.query(func.count(User.id)).filter(User.created_at >= week_ago).scalar(),
    )


# ---------------------------------------------------------------------------
# User management: search/list, verify, ban/unban, roles
# ---------------------------------------------------------------------------

@router.get("/users", response_model=List[AdminUserOut])
def list_users(
    q: Optional[str] = Query(None, description="Search by username, display name, or email"),
    banned: Optional[bool] = None,
    verified: Optional[bool] = None,
    limit: int = Query(50, le=100),
    offset: int = 0,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_moderator),
):
    query = db.query(User)
    if q:
        like = f"%{q}%"
        query = query.filter((User.username.ilike(like)) | (User.display_name.ilike(like)) | (User.email.ilike(like)))
    if banned is not None:
        query = query.filter(User.is_banned == banned)
    if verified is not None:
        query = query.filter(User.is_verified == verified)
    return query.order_by(User.created_at.desc()).offset(offset).limit(limit).all()


@router.post("/users/{user_id}/verify", response_model=AdminUserOut)
def verify_user(user_id: str, db: Session = Depends(get_db), _: User = Depends(get_current_moderator)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_verified = True
    db.commit()
    db.refresh(user)
    return user


@router.post("/users/{user_id}/unverify", response_model=AdminUserOut)
def unverify_user(user_id: str, db: Session = Depends(get_db), _: User = Depends(get_current_moderator)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_verified = False
    db.commit()
    db.refresh(user)
    return user


@router.post("/users/{user_id}/ban", response_model=AdminUserOut)
def ban_user(user_id: str, payload: BanRequest, db: Session = Depends(get_db),
             admin: User = Depends(get_current_moderator)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.role == UserRole.admin:
        raise HTTPException(status_code=403, detail="Cannot ban an admin")
    user.is_banned = True
    user.ban_reason = payload.reason
    user.banned_at = datetime.utcnow()
    db.commit()
    db.refresh(user)
    return user


@router.post("/users/{user_id}/unban", response_model=AdminUserOut)
def unban_user(user_id: str, db: Session = Depends(get_db), _: User = Depends(get_current_moderator)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_banned = False
    user.ban_reason = None
    db.commit()
    db.refresh(user)
    return user


@router.post("/users/{user_id}/role", response_model=AdminUserOut)
def set_role(user_id: str, payload: RoleUpdate, db: Session = Depends(get_db),
             _: User = Depends(get_current_admin)):
    """Admin-only: promote/demote a user between user, moderator, and admin."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.role = UserRole(payload.role)
    db.commit()
    db.refresh(user)
    return user


# ---------------------------------------------------------------------------
# Content moderation: review reports, remove content
# ---------------------------------------------------------------------------

@router.get("/reports", response_model=List[ReportOut])
def list_reports(
    status_filter: Optional[str] = Query(None, alias="status", pattern=r"^(pending|resolved|dismissed)$"),
    limit: int = Query(50, le=100),
    offset: int = 0,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_moderator),
):
    query = db.query(Report)
    if status_filter:
        query = query.filter(Report.status == ReportStatus(status_filter))
    else:
        query = query.filter(Report.status == ReportStatus.pending)
    return query.order_by(Report.created_at.desc()).offset(offset).limit(limit).all()


@router.post("/reports/{report_id}/resolve", response_model=ReportOut)
def resolve_report(report_id: str, payload: ReportResolve, db: Session = Depends(get_db),
                    moderator: User = Depends(get_current_moderator)):
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    report.status = ReportStatus(payload.status)
    report.resolution_note = payload.resolution_note
    report.resolved_by = moderator.id
    report.resolved_at = datetime.utcnow()
    db.commit()
    db.refresh(report)
    return report


@router.delete("/posts/{post_id}", status_code=204)
def admin_delete_post(post_id: str, db: Session = Depends(get_db), _: User = Depends(get_current_moderator)):
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    db.delete(post)
    db.commit()


@router.delete("/comments/{comment_id}", status_code=204)
def admin_delete_comment(comment_id: str, db: Session = Depends(get_db), _: User = Depends(get_current_moderator)):
    comment = db.query(Comment).filter(Comment.id == comment_id).first()
    if not comment:
        raise HTTPException(status_code=404, detail="Comment not found")
    db.delete(comment)
    db.commit()


# ---------------------------------------------------------------------------
# Ad campaigns — transparent, always-labeled promotion
# ---------------------------------------------------------------------------

def _ad_out(ad: AdCampaign, db: Session) -> AdCampaignOut:
    impressions = db.query(func.count(AdEvent.id)).filter_by(ad_id=ad.id, event_type="impression").scalar()
    clicks = db.query(func.count(AdEvent.id)).filter_by(ad_id=ad.id, event_type="click").scalar()
    return AdCampaignOut(
        id=ad.id, name=ad.name, advertiser_name=ad.advertiser_name, media_url=ad.media_url,
        target_url=ad.target_url, caption=ad.caption, budget_cents=int(ad.budget_cents),
        status=ad.status.value, starts_at=ad.starts_at, ends_at=ad.ends_at, created_at=ad.created_at,
        impressions=impressions, clicks=clicks,
    )


@router.get("/ads", response_model=List[AdCampaignOut])
def list_ads(db: Session = Depends(get_db), _: User = Depends(get_current_moderator)):
    ads = db.query(AdCampaign).order_by(AdCampaign.created_at.desc()).all()
    return [_ad_out(a, db) for a in ads]


@router.post("/ads", response_model=AdCampaignOut, status_code=201)
def create_ad(payload: AdCampaignCreate, db: Session = Depends(get_db), admin: User = Depends(get_current_admin)):
    ad = AdCampaign(
        name=payload.name, advertiser_name=payload.advertiser_name, media_url=payload.media_url,
        target_url=payload.target_url, caption=payload.caption, budget_cents=str(payload.budget_cents),
        starts_at=payload.starts_at, ends_at=payload.ends_at, created_by=admin.id,
    )
    db.add(ad)
    db.commit()
    db.refresh(ad)
    return _ad_out(ad, db)


@router.patch("/ads/{ad_id}", response_model=AdCampaignOut)
def update_ad(ad_id: str, payload: AdCampaignUpdate, db: Session = Depends(get_db),
              _: User = Depends(get_current_admin)):
    ad = db.query(AdCampaign).filter(AdCampaign.id == ad_id).first()
    if not ad:
        raise HTTPException(status_code=404, detail="Ad campaign not found")
    if payload.status is not None:
        ad.status = AdStatus(payload.status)
    if payload.budget_cents is not None:
        ad.budget_cents = str(payload.budget_cents)
    if payload.ends_at is not None:
        ad.ends_at = payload.ends_at
    db.commit()
    db.refresh(ad)
    return _ad_out(ad, db)


@router.delete("/ads/{ad_id}", status_code=204)
def delete_ad(ad_id: str, db: Session = Depends(get_db), _: User = Depends(get_current_admin)):
    ad = db.query(AdCampaign).filter(AdCampaign.id == ad_id).first()
    if not ad:
        raise HTTPException(status_code=404, detail="Ad campaign not found")
    db.delete(ad)
    db.commit()
