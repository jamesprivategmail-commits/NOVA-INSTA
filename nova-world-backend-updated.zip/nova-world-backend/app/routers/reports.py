from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Report, ReportTargetType, User
from ..schemas import ReportCreate, ReportOut
from ..auth import get_current_user

router = APIRouter(prefix="/reports", tags=["reports"])


@router.post("", response_model=ReportOut, status_code=201)
def create_report(payload: ReportCreate, db: Session = Depends(get_db),
                   current_user: User = Depends(get_current_user)):
    report = Report(
        reporter_id=current_user.id,
        target_type=ReportTargetType(payload.target_type),
        target_id=payload.target_id,
        reason=payload.reason,
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report
