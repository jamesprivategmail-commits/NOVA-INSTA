from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Conversation, ConversationParticipant, DirectMessage, User, Notification, NotificationType
from ..schemas import MessageCreate, MessageOut, ConversationOut, UserOut
from ..auth import get_current_user
from ..push import notify_user

router = APIRouter(prefix="/messages", tags=["messages"])


def _get_or_create_conversation(db: Session, user_a: str, user_b: str) -> Conversation:
    # Find an existing 1:1 conversation containing exactly these two participants.
    my_convo_ids = {
        p.conversation_id for p in db.query(ConversationParticipant).filter_by(user_id=user_a).all()
    }
    for convo_id in my_convo_ids:
        participant_ids = {
            p.user_id for p in db.query(ConversationParticipant).filter_by(conversation_id=convo_id).all()
        }
        if participant_ids == {user_a, user_b}:
            return db.query(Conversation).filter_by(id=convo_id).first()

    convo = Conversation()
    db.add(convo)
    db.flush()
    db.add(ConversationParticipant(conversation_id=convo.id, user_id=user_a))
    db.add(ConversationParticipant(conversation_id=convo.id, user_id=user_b))
    return convo


@router.get("", response_model=List[ConversationOut])
def list_conversations(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    my_participations = db.query(ConversationParticipant).filter_by(user_id=current_user.id).all()
    results = []
    for p in my_participations:
        other = (
            db.query(ConversationParticipant)
            .filter(ConversationParticipant.conversation_id == p.conversation_id,
                    ConversationParticipant.user_id != current_user.id)
            .first()
        )
        if not other:
            continue
        other_user = db.query(User).filter(User.id == other.user_id).first()
        last_msg = (
            db.query(DirectMessage)
            .filter(DirectMessage.conversation_id == p.conversation_id)
            .order_by(DirectMessage.created_at.desc())
            .first()
        )
        unread_count = (
            db.query(func.count(DirectMessage.id))
            .filter(
                DirectMessage.conversation_id == p.conversation_id,
                DirectMessage.sender_id != current_user.id,
                DirectMessage.created_at > (p.last_read_at or datetime.min),
            )
            .scalar()
        )
        convo = db.query(Conversation).filter_by(id=p.conversation_id).first()
        results.append(ConversationOut(
            id=p.conversation_id,
            other_user=UserOut.model_validate(other_user),
            last_message=MessageOut.model_validate(last_msg) if last_msg else None,
            unread_count=unread_count,
            created_at=convo.created_at,
        ))
    results.sort(key=lambda c: c.last_message.created_at if c.last_message else c.created_at, reverse=True)
    return results


@router.get("/{username}", response_model=List[MessageOut])
def get_thread(username: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    other = db.query(User).filter(User.username == username).first()
    if not other:
        raise HTTPException(status_code=404, detail="User not found")

    convo = _get_or_create_conversation(db, current_user.id, other.id)
    db.commit()

    participant = db.query(ConversationParticipant).filter_by(conversation_id=convo.id, user_id=current_user.id).first()
    participant.last_read_at = datetime.utcnow()
    db.commit()

    return (
        db.query(DirectMessage)
        .filter(DirectMessage.conversation_id == convo.id)
        .order_by(DirectMessage.created_at.asc())
        .limit(200)
        .all()
    )


@router.post("/{username}", response_model=MessageOut, status_code=201)
def send_message(username: str, payload: MessageCreate, db: Session = Depends(get_db),
                  current_user: User = Depends(get_current_user)):
    if username == current_user.username:
        raise HTTPException(status_code=400, detail="Cannot message yourself")
    if not payload.text and not payload.media_url:
        raise HTTPException(status_code=400, detail="Message must have text or media")

    other = db.query(User).filter(User.username == username).first()
    if not other:
        raise HTTPException(status_code=404, detail="User not found")

    convo = _get_or_create_conversation(db, current_user.id, other.id)
    msg = DirectMessage(conversation_id=convo.id, sender_id=current_user.id,
                         text=payload.text, media_url=payload.media_url)
    db.add(msg)
    db.commit()
    db.refresh(msg)

    notify_user(db, other.id, f"Message from @{current_user.username}",
                payload.text[:100] if payload.text else "Sent a photo",
                {"type": "message", "username": current_user.username})
    return msg
