"""
Push notification delivery.

Uses the Expo push API (https://exp.host/--/api/v2/push/send), which accepts
tokens from any Expo-managed React Native app for free, for both iOS and
Android, without needing a Firebase/APNs project set up first. If you build a
bare native app later, swap `_send_via_expo` for direct FCM/APNs calls — the
call sites (`notify_user` / `notify_users`) don't need to change.

Delivery failures are logged and swallowed: a push failure should never break
the API request that triggered it (e.g. liking a post shouldn't 500 because
someone's push token expired).
"""
import logging
import os
from typing import Iterable, Optional

import requests
from sqlalchemy.orm import Session

from .models import PushDevice

logger = logging.getLogger("nova.push")

EXPO_PUSH_URL = "https://exp.host/--/api/v2/push/send"
PUSH_ENABLED = os.environ.get("PUSH_ENABLED", "true").lower() == "true"


def _send_via_expo(tokens: list[str], title: str, body: str, data: Optional[dict] = None) -> None:
    if not tokens or not PUSH_ENABLED:
        return
    messages = [
        {"to": token, "title": title, "body": body, "data": data or {}, "sound": "default"}
        for token in tokens
    ]
    try:
        resp = requests.post(EXPO_PUSH_URL, json=messages, timeout=5)
        if resp.status_code >= 300:
            logger.warning("Expo push failed: %s %s", resp.status_code, resp.text[:300])
    except requests.RequestException as exc:
        logger.warning("Expo push request error: %s", exc)


def notify_user(db: Session, user_id: str, title: str, body: str, data: Optional[dict] = None) -> None:
    tokens = [d.token for d in db.query(PushDevice).filter(PushDevice.user_id == user_id).all()]
    _send_via_expo(tokens, title, body, data)


def notify_users(db: Session, user_ids: Iterable[str], title: str, body: str, data: Optional[dict] = None) -> None:
    tokens = [d.token for d in db.query(PushDevice).filter(PushDevice.user_id.in_(list(user_ids))).all()]
    _send_via_expo(tokens, title, body, data)
