# Nova World API

FastAPI backend for Nova World: auth, profiles, posts (photo/video), likes, comments,
follows, notifications, direct messages, stories, push notifications, and an admin API
for moderation and disclosed ad campaigns.

## Stack
- **API**: FastAPI (Python), JWT auth (access + refresh tokens), bcrypt password hashing
- **Database**: Postgres (Render managed), schema managed by **Alembic migrations**
- **Media storage**: any S3-compatible bucket (Cloudflare R2 recommended — free egress, S3 API)
- **Push**: Expo push API (works for any Expo-managed React Native app on iOS + Android, no Firebase project needed to start)
- **Hosting**: Render web service, auto-deploys from `main`

## Setup
1. Push this folder to a GitHub repo.
2. On Render: **New > Blueprint**, point it at the repo — `render.yaml` provisions the Postgres DB and web service together, and now runs `alembic upgrade head` before starting the server.
3. Create an S3-compatible bucket, fill in the `S3_*` env vars in the Render dashboard.
4. Promote your own account to admin once deployed (see **Bootstrapping an admin** below) so you can access `/admin/*`.

## Database migrations
Schema changes are managed with Alembic instead of `create_all`, so you can evolve the
schema without dropping data.

```bash
# create a new migration after changing app/models.py
alembic revision --autogenerate -m "add saved_posts table"

# apply migrations (this now also runs automatically on Render deploys)
alembic upgrade head

# roll back one revision
alembic downgrade -1
```

`alembic/env.py` reads `DATABASE_URL` from the environment, same as the app itself, so
it works locally, in CI, and on Render without a separate config file. The full current
schema lives in `alembic/versions/0001_initial_schema.py` as the baseline.

## Bootstrapping an admin
There's no signup flow for admins on purpose — the first one has to be granted directly
against the database to avoid a chicken-and-egg auth problem:

```sql
UPDATE users SET role = 'admin' WHERE username = 'your_username';
```

Every admin after that can be promoted via `POST /admin/users/{id}/role` instead.

## API overview

### Core (existing)
| Endpoint | Method | Purpose |
|---|---|---|
| `/auth/signup`, `/auth/login`, `/auth/refresh` | POST | Account + tokens |
| `/users/me`, `/users/{username}` | GET/PATCH | Profiles |
| `/users/{username}/follow` | POST/DELETE | Follow / unfollow |
| `/posts`, `/posts/feed`, `/posts/explore` | POST/GET | Posts |
| `/posts/{id}/like`, `/posts/{id}/comments` | POST/DELETE/GET | Engagement |
| `/notifications` | GET | Pull-based notification list |

### New: direct messages
| Endpoint | Method | Purpose |
|---|---|---|
| `/messages` | GET | List conversations, sorted by latest activity, with unread counts |
| `/messages/{username}` | GET | Full thread with a user (creates the conversation if new) |
| `/messages/{username}` | POST | Send a text and/or media message; triggers a push notification |

### New: stories (24h ephemeral posts)
| Endpoint | Method | Purpose |
|---|---|---|
| `/stories` | POST | Upload a story (image/video), expires in 24h |
| `/stories/feed` | GET | Active stories from people you follow, grouped by author |
| `/stories/user/{username}` | GET | One user's active stories |
| `/stories/{id}/view` | POST | Mark viewed (dedup'd per viewer) |
| `/stories/{id}` | DELETE | Delete your own story early |

Expired stories aren't auto-purged from the DB by this code — add a daily Render Cron
Job running a `DELETE FROM stories WHERE expires_at < now()` (or a small script) to
actually reclaim storage/rows; not wired up yet since it's infra, not app code.

### New: push notifications
| Endpoint | Method | Purpose |
|---|---|---|
| `/users/me/push-devices` | POST | Register an Expo push token for this device |
| `/users/me/push-devices/{token}` | DELETE | Unregister on logout |

Likes, comments, follows, and DMs already call `notify_user()` — wire the client to
call `Notifications.getExpoPushTokenAsync()` (Expo SDK) on login and POST it here.
Set `PUSH_ENABLED=false` in env to no-op push (useful in CI/dev).

### New: reports (user-facing)
| Endpoint | Method | Purpose |
|---|---|---|
| `/reports` | POST | Report a post, comment, or user for moderator review |

### New: admin API (role-gated — moderator or admin)
| Endpoint | Method | Purpose |
|---|---|---|
| `/admin/stats` | GET | Dashboard summary numbers |
| `/admin/users` | GET | Search/filter users (by name, banned, verified) |
| `/admin/users/{id}/verify`, `/unverify` | POST | Toggle the verified badge |
| `/admin/users/{id}/ban`, `/unban` | POST | Suspend / restore an account, with a required reason |
| `/admin/users/{id}/role` | POST | Promote/demote user ↔ moderator ↔ admin (**admin only**) |
| `/admin/reports` | GET | Review queue, filterable by status |
| `/admin/reports/{id}/resolve` | POST | Resolve or dismiss a report with a note |
| `/admin/posts/{id}`, `/admin/comments/{id}` | DELETE | Remove content that breaks policy |
| `/admin/ads` | GET/POST | List / create ad campaigns (**create is admin only**) |
| `/admin/ads/{id}` | PATCH/DELETE | Update status/budget, or remove a campaign |
| `/ads/active` | GET | Public: ads to splice into the feed, client-side, always labeled "Sponsored" |
| `/ads/{id}/impression`, `/click` | POST | Public: real engagement tracking for advertiser reporting |

**What the admin API deliberately does *not* do:** inflate follower/like/view counts,
or force a specific post to "go viral." That would misrepresent real engagement to your
own users and to anyone paying for ads on the platform — it's the kind of thing that
gets an app pulled from the App Store and exposes you to fraud claims from advertisers.
The honest equivalent is the ad campaign flow above (always rendered as a labeled ad),
or a `featured` flag on `Post` for an editorial "Staff Picks" row — say the word if you
want that added.

Interactive docs are auto-generated at `/docs` once deployed.

## Security notes
- Passwords are bcrypt-hashed, never stored or logged in plain text.
- Access tokens expire in 30 min; refresh tokens in 30 days.
- Banned users' tokens are rejected at `get_current_user` — a ban takes effect immediately, not just on next login.
- `CORSMiddleware` currently allows `*` — restrict `allow_origins` to your actual web/mobile app domains before launch.
- File uploads are type- and size-validated server-side (25MB cap, image/video allowlist).
- Admin/moderator endpoints require `role` in the JWT-authenticated user record, checked server-side on every request — never trust a client-sent role.

## Scaling plan
- **Now (MVP)**: single Render web service + single Postgres instance handles low thousands of users fine.
- **Media**: put a CDN in front of `S3_PUBLIC_BASE_URL` (Cloudflare does this for free on R2).
- **Feed reads**: add Redis for feed/profile caching and move to write-time fan-out as volume grows.
- **DMs**: current polling-based (`GET /messages/{username}`); add WebSockets for real-time delivery when needed.
- **Web service**: stateless (JWT, no server-side sessions) — scaling to multiple instances is a Render config change.
- **Database**: add composite indexes on hot query paths as volume grows; Render Postgres supports read replicas.

## Not yet built
- Full frontend / mobile app (this repo is backend-only; see project chat for the admin dashboard, delivered separately)
- Rate limiting / abuse prevention on signup, uploads, and messaging
- Story cleanup cron job (see note above)
- Real-time delivery (WebSockets) for messages and notifications — currently pull/poll-based
